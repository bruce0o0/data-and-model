#!usr/bin/env python
# -*- coding: utf-8 -*-


import pandas as pd
from datetime import datetime
from copper_prediction.util import RAW_DATA, PROCESS_LEVEL1

pd.options.display.expand_frame_repr = False


# index_col: 指定索引列。
# 关注对时间处理的模块
raw_data = pd.read_csv(RAW_DATA, index_col=0)
raw_data.columns = ['price', 'M2', 'balance sheet', 'national debt treasury', 'interest rate', 'pmi', 'gdp', 'unemployment', 'LME', 'NYMEX', 'SHFE', 'CPI', 'exchange', 'PPI']
raw_data.index.name = 'date'

print(raw_data.head())
raw_data.to_csv(PROCESS_LEVEL1)
