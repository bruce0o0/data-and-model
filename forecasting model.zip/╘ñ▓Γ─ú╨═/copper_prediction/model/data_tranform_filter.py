#!usr/bin/env python
# -*- coding: utf-8 -*-


import pandas as pd
from copper_prediction.util import PROCESS_LEVEL1
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import MinMaxScaler
from sklearn.preprocessing import OneHotEncoder
from copper_prediction.model.series_to_supervised_learning import series_to_supervised
pd.options.display.expand_frame_repr = False


dataset = pd.read_csv(PROCESS_LEVEL1, header=0, index_col=0)
dataset.drop(['M2', 'balance sheet', 'national debt treasury', 'interest rate', 'unemployment'], axis=1, inplace=True)
dataset_columns = dataset.columns

values = dataset.values

# 对数据进行归一化处理
scaler_f = MinMaxScaler(feature_range=(0, 1))
scaled_f = scaler_f.fit_transform(values)

# 将序列数据转化为监督学习数据
reframed_f = series_to_supervised(scaled_f, dataset_columns, 1, 1)
# 只考虑当前时刻(t)的前一时刻（t-1）
reframed_f.drop(reframed_f.columns[[ 10, 11, 12, 13, 14, 15, 16, 17]], axis=1, inplace=True)

values = reframed_f.values
n_train_data = 60 #2018年之前
train = values[:n_train_data, :]
test = values[n_train_data:, :]

# 监督学习结果划分,test_x.shape = (, 8)
train_x_f, train_y_f = train[:, :-1], train[:, -1]
test_x_f, test_y_f = test[:, :-1], test[:, -1]

# 为了在LSTM中应用该数据，需要将其格式转化为3D format，即[Samples, timesteps, features]
train_X_f = train_x_f.reshape((train_x_f.shape[0], 1, train_x_f.shape[1]))
test_X_f = test_x_f.reshape((test_x_f.shape[0], 1, test_x_f.shape[1]))
