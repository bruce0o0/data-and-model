#!usr/bin/env python
# -*- coding: utf-8 -*-


from keras import Sequential
from keras.layers import LSTM, Dense
from copper_prediction.model.data_tranform import scaler, test_x, train_X, test_X, train_y, test_y
from copper_prediction.model.data_tranform_filter import scaler_f, test_x_f, train_X_f, test_X_f, train_y_f, test_y_f
import matplotlib.pyplot as plt
from numpy import concatenate  # 数组拼接
from math import sqrt
from sklearn.metrics import mean_squared_error
EPOCHES=250
BATCHSIZE=12

# ##--------------------------baseline------------------------------
model = Sequential()
model.add(LSTM(50, input_shape=(train_X.shape[1], train_X.shape[2])))
model.add(Dense(1))
model.compile(loss='mae', optimizer='adam')
history = model.fit(train_X, train_y, epochs=EPOCHES, batch_size=BATCHSIZE, validation_data=(test_X, test_y))

# make the prediction,为了在原始数据的维度上计算损失，需要将数据转化为原来的范围再计算损失
yHat = model.predict(test_X)

'''
    这里注意的是保持拼接后的数组  列数  需要与之前的保持一致
'''
inv_yHat = concatenate((yHat, test_x[:, 1:]), axis=1)   # 数组拼接
print(inv_yHat.shape)
inv_yHat = scaler.inverse_transform(inv_yHat)
inv_yHat = inv_yHat[:, 0]

test_y = test_y.reshape((len(test_y), 1))
inv_y = concatenate((test_y, test_x[:, 1:]), axis=1)
inv_y = scaler.inverse_transform(inv_y)    # 将标准化的数据转化为原来的范围
inv_y = inv_y[:, 0]

rmse = sqrt(mean_squared_error(inv_yHat, inv_y))


##--------------------------our model------------------------------
model_f = Sequential()
model_f.add(LSTM(50, input_shape=(train_X_f.shape[1], train_X_f.shape[2])))
model_f.add(Dense(1))
model_f.compile(loss='mae', optimizer='adam')
history_f = model_f.fit(train_X_f, train_y_f, epochs=EPOCHES, batch_size=BATCHSIZE, validation_data=(test_X_f, test_y_f))

# make the prediction,为了在原始数据的维度上计算损失，需要将数据转化为原来的范围再计算损失
yHat_f = model_f.predict(test_X_f)

'''
    这里注意的是保持拼接后的数组  列数  需要与之前的保持一致
'''
inv_yHat_f = concatenate((yHat_f, test_x_f[:, 1:]), axis=1)   # 数组拼接
print(inv_yHat_f.shape)
inv_yHat_f = scaler_f.inverse_transform(inv_yHat_f)
inv_yHat_f = inv_yHat_f[:, 0]

test_y_f = test_y_f.reshape((len(test_y_f), 1))
inv_y_f = concatenate((test_y_f, test_x_f[:, 1:]), axis=1)
inv_y_f = scaler_f.inverse_transform(inv_y_f)    # 将标准化的数据转化为原来的范围
inv_y_f = inv_y_f[:, 0]

rmse_f = sqrt(mean_squared_error(inv_yHat_f, inv_y_f))




'''
    对数据绘图
'''
font1 = {'family' : 'MicroSoft YaHei',
'weight' : 'normal',
'size'   : 13,
         }

font2 = {'family' : 'MicroSoft YaHei',
'weight' : 'normal',
'size'   : 11,
         }



plt.xlabel("Iteration",font1)
plt.ylabel("Loss",font1)
plt.plot(history.history['loss'], label='原始模型训练损失')
plt.plot(history.history['val_loss'], label='原始模型测试损失')
plt.plot(history_f.history['loss'], label='过滤后模型训练损失')
plt.plot(history_f.history['val_loss'], label='过滤后模型测试损失')
plt.legend(prop=font2)
plt.title('模型损失', font2)
plt.savefig('../模型损失', dpi=300)
plt.show()


# plot data
date = ['2019/1','2019/2','2019/3','2019/4','2019/5','2019/6','2019/7','2019/8','2019/9','2019/10','2019/11','2019/12',
        '2020/1','2020/2','2020/3','2020/4','2020/5','2020/6','2020/7','2020/8','2020/9','2020/10','2020/11','2020/12',
        '2021/1','2021/2','2021/3','2021/4','2021/5','2021/6','2021/7','2021/8','2021/9'
        ]
plt.xlabel("时间",font1)
plt.ylabel("铜价格(元/吨)",font1)
plt.plot(date,inv_y,label='真实价格')
plt.plot(date,inv_yHat, label='原始模型预测价格')
plt.plot(date,inv_yHat_f, label='过滤后模型预测价格')
plt.legend(prop=font2)
xticks=list(range(0,len(date),5))
plt.xticks(xticks)
plt.title('铜价预测结果', font2)
plt.savefig('../铜价预测结果', dpi=300)
plt.show()

#loss
print('baseline test RMSE: %.3f' % rmse)
print('our model RMSE: %.3f' % rmse_f)