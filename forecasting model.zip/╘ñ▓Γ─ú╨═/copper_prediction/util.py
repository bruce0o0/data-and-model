#!usr/bin/env python
# -*- coding: utf-8 -*-

"""
Time:17/1/1
---------------------------
Question:  常量
---------------------------
"""

RAW_DATA = '../resource/copper.csv'
PROCESS_LEVEL1 = '../resource/price.csv'
