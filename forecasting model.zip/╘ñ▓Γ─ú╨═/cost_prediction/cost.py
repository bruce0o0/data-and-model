import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split

from numpy import arange
from matplotlib import pyplot
from pandas import  set_option
from pandas.plotting import scatter_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import mean_squared_error

from sklearn.feature_selection import SelectKBest
from sklearn.feature_selection import f_regression


def testHouse():
    # 读取房屋数据集
    data = pd.read_csv("elect.csv")
    # 通过 head 方法查看数据集的前几行数据
    set_option('display.column_space', 45)
    # print(df.head())

    # 数据维度
    print(data.shape)

    # 特征属性的字段类型
    # print(data.dtypes)

    #检查有没有数据中有没有空值
    print(data.isnull().any().sum())

    # 描述性统计信息
    # set_option('precision', 1)
    # print(data.describe())

    #提取特征和标记
    prices = data['cost']
    features = data.drop('cost', axis=1)

    # 关联关系
    # set_option('precision', 2)
    # print(data.corr(method='pearson'))

    # 直方图
    # data.hist(sharex=False, sharey=False, xlabelsize=1, ylabelsize=1)
    # pyplot.show()

    # 密度图
    # data.plot(kind='density', subplots=True, layout=(4, 4), sharex=False, fontsize=1)
    # pyplot.show()

    # 箱线图
    # data.plot(kind='box', subplots=True, layout=(4, 4), sharex=False, sharey=False, fontsize=8)
    # pyplot.show()

    # 查看各个特征的散点分布
    scatter_matrix(data, alpha=0.7, figsize=(10, 10), diagonal='kde')
    pyplot.show()


def featureSelection():
    data = pd.read_csv("elect.csv")
    x = data[['ele type', 'project type', 'outwire type', 'outwire length', 'ele capacity', 'location', 'users', 'inwire length', 'pipe length', 'ele number',
              'transfomer', 'copper']]
    # print(x.head())
    y = data['cost']

    #特征选择
    from sklearn.feature_selection import SelectKBest
    SelectKBest = SelectKBest(f_regression, k=7)
    bestFeature = SelectKBest.fit_transform(x, y)
    SelectKBest.get_support(indices=False)

    # print(SelectKBest.transform(x))
    print(x.columns[SelectKBest.get_support(indices=False)])

    features = data[['project type', 'outwire length', 'ele capacity', 'users','inwire length', 'ele number', 'transfomer', 'copper']].copy()
    # print(features)

    values = features.values

    # 对数据进行归一化处理
    from sklearn.preprocessing import MinMaxScaler
    scaler = MinMaxScaler(feature_range=(0, 1))
    scaled = scaler.fit_transform(values)
    print(scaled)

    n_train_data = 30
    x_train = values[:n_train_data, :]
    x_test = values[n_train_data:, :]

    y = y.values
    y=y.reshape(-1,1)
    y=scaler.fit_transform(y)
    y_train =y[:n_train_data]
    y_test = y[n_train_data:]



    from sklearn.tree import DecisionTreeRegressor
    estimator = DecisionTreeRegressor()
    estimator.fit(x_train, y_train)
    #小数据集自动调参
    estimator = GridSearchCV(estimator, param_grid={}, cv=5)
    estimator.fit(x_train, y_train)

    y_test_predict = estimator.predict(x_test)
    print(y_test)
    print(y_test_predict)

    print('MSE: ', mean_squared_error(y_test, y_test_predict))
    print('RMSE: ', np.sqrt(mean_squared_error(y_test, y_test_predict)))

    '''
        对数据绘图
    '''
    font1 = {'family' : 'MicroSoft YaHei',
    'weight' : 'normal',
    'size'   : 13,
             }

    plt.xlabel("项目编号", font1)
    plt.ylabel("成本(元)", font1)
    plt.plot(y_test, label='实际成本')
    plt.plot(y_test_predict, label='模型预测成本')
    plt.legend(prop=font1)
    plt.title('成本预测结果', font1)
    plt.savefig("成本预测", dpi=300)
    plt.show()



def main():
    # testHouse()
    featureSelection()




if __name__ == "__main__":
    main()